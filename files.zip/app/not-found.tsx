export default function NotFound() {
  return (
    <main
      style={{
        minHeight: "100vh",
        display: "grid",
        placeItems: "center",
        background: "linear-gradient(180deg,#1a0a12,#120b11)",
        color: "#fff"
      }}
    >
      <div style={{ textAlign: "center" }}>
        <h1 style={{ fontSize: 48, marginBottom: 8 }}>404</h1>
        <p style={{ opacity: 0.8 }}>Card not found.</p>
        <a href="/" style={{ display: "inline-block", marginTop: 12, color: "#ffb9de" }}>
          Back to home
        </a>
      </div>
    </main>
  );
}