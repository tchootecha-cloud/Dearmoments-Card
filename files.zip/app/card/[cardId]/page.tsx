import { notFound } from "next/navigation";
import type { Metadata } from "next";
import CardViewer, { type CardData } from "./CardViewer";
import { getCardById } from "@/lib/card-service";

export const dynamic = "force-dynamic";

type Props = {
  params: { cardId: string };
};

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { cardId } = params;

  return {
    title: `Card - ${cardId}`,
    robots: { index: false, follow: false }
  };
}

export default async function CardPage({ params }: Props) {
  const { cardId } = params;
  const card = await getCardById(cardId);

  if (!card) {
    notFound();
  }

  const data: CardData = {
    id: card.id,
    category: card.category ?? "love",
    images: card.images ?? [],
    videoUrl: card.videoUrl ?? null,
    message: card.message ?? "",
    musicUrl: card.musicUrl ?? null
  };

  return <CardViewer card={data} />;
}