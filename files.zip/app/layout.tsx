import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Love Card",
  description: "Card viewer app",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="th">
      <body>{children}</body>
    </html>
  );
}