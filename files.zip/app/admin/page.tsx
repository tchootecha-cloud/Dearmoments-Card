"use client";

import { useEffect, useState, type CSSProperties } from "react";

type CardForm = {
  id: string;
  title: string;
  category: string;
  images: string;
  videoUrl: string;
  musicUrl: string;
  message: string;
};

type CardRecord = {
  id: string;
  title: string;
  category: string;
  images: string[];
  videoUrl: string | null;
  musicUrl: string | null;
  message: string;
};

const categories = ["love", "congrat", "thanks", "sorry", "birthday", "anniv", "cheer", "miss"];

const emptyForm: CardForm = {
  id: "",
  title: "",
  category: "love",
  images: "",
  videoUrl: "",
  musicUrl: "",
  message: ""
};

export default function AdminPage() {
  const [form, setForm] = useState<CardForm>(emptyForm);
  const [cards, setCards] = useState<CardRecord[]>([]);
  const [saving, setSaving] = useState(false);
  const [status, setStatus] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);

  const loadCards = async () => {
    const res = await fetch("/api/cards");
    const data = await res.json();
    setCards(data);
  };

  useEffect(() => {
    loadCards();
  }, []);

  const resetForm = () => {
    setForm(emptyForm);
    setEditingId(null);
    setStatus("");
  };

  const submit = async () => {
    if (!form.id.trim() || !form.title.trim()) {
      setStatus("Please fill ID and Title.");
      return;
    }

    setSaving(true);

    const payload = {
      id: form.id.trim(),
      title: form.title.trim(),
      category: form.category,
      images: form.images
        .split(",")
        .map((item) => item.trim())
        .filter(Boolean),
      videoUrl: form.videoUrl.trim() || null,
      musicUrl: form.musicUrl.trim() || null,
      message: form.message.trim()
    };

    const url = editingId ? `/api/cards/${editingId}` : "/api/cards";
    const method = editingId ? "PUT" : "POST";

    const res = await fetch(url, {
      method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });

    const data = await res.json();

    if (!res.ok) {
      setStatus(data.error || "Failed to save card");
      setSaving(false);
      return;
    }

    setStatus(editingId ? "Card updated successfully." : "Card created successfully.");
    setSaving(false);

    resetForm();
    loadCards();
  };

  const startEdit = (card: CardRecord) => {
    setEditingId(card.id);
    setForm({
      id: card.id,
      title: card.title,
      category: card.category,
      images: (card.images || []).join(", "),
      videoUrl: card.videoUrl || "",
      musicUrl: card.musicUrl || "",
      message: card.message || ""
    });
    setStatus("Editing card...");
  };

  const deleteCard = async (id: string) => {
    const ok = window.confirm("Delete this card?");
    if (!ok) return;

    const res = await fetch(`/api/cards/${id}`, { method: "DELETE" });

    if (!res.ok) {
      setStatus("Failed to delete card.");
      return;
    }

    setStatus("Card deleted.");
    loadCards();

    if (editingId === id) {
      resetForm();
    }
  };

  return (
    <main
      style={{
        minHeight: "100vh",
        background: "linear-gradient(180deg,#160b12,#120910)",
        padding: 36
      }}
    >
      <div
        style={{
          maxWidth: 1150,
          margin: "0 auto",
          display: "grid",
          gridTemplateColumns: "1.1fr 0.9fr",
          gap: 22
        }}
      >
        <section
          style={{
            background: "rgba(255,255,255,0.04)",
            border: "1px solid rgba(255,255,255,0.12)",
            borderRadius: 24,
            padding: 26
          }}
        >
          <h1 style={{ marginTop: 0 }}>Create / Edit Card</h1>

          <div style={{ display: "grid", gap: 14 }}>
            <input
              value={form.id}
              onChange={(e) => setForm({ ...form, id: e.target.value })}
              placeholder="Card ID (unique)"
              style={inputStyle}
            />

            <input
              value={form.title}
              onChange={(e) => setForm({ ...form, title: e.target.value })}
              placeholder="Title"
              style={inputStyle}
            />

            <select
              value={form.category}
              onChange={(e) => setForm({ ...form, category: e.target.value })}
              style={inputStyle}
            >
              {categories.map((category) => (
                <option key={category} value={category}>
                  {category}
                </option>
              ))}
            </select>

            <input
              value={form.images}
              onChange={(e) => setForm({ ...form, images: e.target.value })}
              placeholder="Image URLs separated by comma"
              style={inputStyle}
            />

            <input
              value={form.videoUrl}
              onChange={(e) => setForm({ ...form, videoUrl: e.target.value })}
              placeholder="Video URL"
              style={inputStyle}
            />

            <input
              value={form.musicUrl}
              onChange={(e) => setForm({ ...form, musicUrl: e.target.value })}
              placeholder="Music URL"
              style={inputStyle}
            />

            <textarea
              value={form.message}
              onChange={(e) => setForm({ ...form, message: e.target.value })}
              rows={8}
              placeholder="Message"
              style={{ ...inputStyle, resize: "vertical" }}
            />

            <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
              <button
                onClick={submit}
                disabled={saving}
                style={{
                  border: 0,
                  borderRadius: 999,
                  background: "#ff8ccf",
                  color: "#1f0816",
                  padding: "12px 22px",
                  fontWeight: 700,
                  cursor: "pointer"
                }}
              >
                {saving ? "Saving..." : editingId ? "Update Card" : "Create Card"}
              </button>

              <button
                onClick={resetForm}
                style={{
                  border: "1px solid rgba(255,255,255,0.14)",
                  background: "transparent",
                  color: "#fff",
                  borderRadius: 999,
                  padding: "12px 18px",
                  cursor: "pointer"
                }}
              >
                Reset
              </button>

              <a
                href="/"
                style={{ display: "inline-flex", alignItems: "center", color: "#fff", opacity: 0.8 }}
              >
                Back to home
              </a>
            </div>

            {status && (
              <div
                style={{
                  background: "rgba(255,255,255,0.05)",
                  border: "1px solid rgba(255,255,255,0.12)",
                  borderRadius: 12,
                  padding: "10px 12px",
                  color: "#d8ffd8"
                }}
              >
                {status}
              </div>
            )}
          </div>
        </section>

        <aside
          style={{
            background: "rgba(255,255,255,0.04)",
            border: "1px solid rgba(255,255,255,0.12)",
            borderRadius: 24,
            padding: 20
          }}
        >
          <h2 style={{ marginTop: 0 }}>Cards List</h2>

          <div style={{ display: "grid", gap: 12 }}>
            {cards.map((card) => (
              <div
                key={card.id}
                style={{
                  background: "rgba(255,255,255,0.03)",
                  border: "1px solid rgba(255,255,255,0.08)",
                  borderRadius: 16,
                  padding: 12
                }}
              >
                <div style={{ display: "flex", gap: 10 }}>
                  <img
                    src={
                      card.images[0] ||
                      "https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=900&q=80"
                    }
                    alt={card.title}
                    style={{
                      width: 72,
                      height: 72,
                      borderRadius: 10,
                      objectFit: "cover"
                    }}
                  />

                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 700 }}>{card.title}</div>
                    <div style={{ opacity: 0.7, fontSize: 12 }}>{card.id}</div>
                    <div style={{ marginTop: 6, fontSize: 12, opacity: 0.8 }}>
                      {card.category}
                    </div>
                  </div>
                </div>

                <div style={{ display: "flex", gap: 8, marginTop: 12, flexWrap: "wrap" }}>
                  <button
                    onClick={() => startEdit(card)}
                    style={{
                      background: "#a6d9ff",
                      color: "#0b1728",
                      border: 0,
                      borderRadius: 999,
                      padding: "8px 12px",
                      cursor: "pointer"
                    }}
                  >
                    Edit
                  </button>

                  <button
                    onClick={() => deleteCard(card.id)}
                    style={{
                      background: "#ff9c9c",
                      color: "#2a0b0d",
                      border: 0,
                      borderRadius: 999,
                      padding: "8px 12px",
                      cursor: "pointer"
                    }}
                  >
                    Delete
                  </button>

                  <a
                    href={`/card/${card.id}`}
                    style={{
                      border: "1px solid rgba(255,255,255,0.14)",
                      color: "#fff",
                      textDecoration: "none",
                      borderRadius: 999,
                      padding: "8px 12px"
                    }}
                  >
                    View
                  </a>
                </div>
              </div>
            ))}
          </div>
        </aside>
      </div>
    </main>
  );
}

const inputStyle: CSSProperties = {
  width: "100%",
  background: "rgba(255,255,255,0.04)",
  border: "1px solid rgba(255,255,255,0.12)",
  borderRadius: 12,
  padding: "12px 14px",
  color: "#fff",
  outline: "none"
};