import { NextResponse } from "next/server";
import { z } from "zod";
import { createCard, listCards } from "@/lib/card-service";

const cardSchema = z.object({
  id: z.string().trim().min(1).optional(),
  title: z.string().trim().min(1),
  category: z.string().default("love"),
  images: z.array(z.string().trim().min(1)).default([]),
  videoUrl: z.string().trim().nullable().optional(),
  musicUrl: z.string().trim().nullable().optional(),
  message: z.string().default("")
});

export async function GET() {
  const cards = await listCards();
  return NextResponse.json(cards);
}

export async function POST(request: Request) {
  try {
    const body = await request.json();

    const parsed = cardSchema.parse({
      ...body,
      images: Array.isArray(body.images) ? body.images : []
    });

    const card = await createCard({
      id: parsed.id,
      title: parsed.title,
      category: parsed.category,
      images: parsed.images,
      videoUrl: parsed.videoUrl ?? null,
      musicUrl: parsed.musicUrl ?? null,
      message: parsed.message
    });

    return NextResponse.json(card, { status: 201 });
  } catch (error: any) {
    if (error?.code === "P2002") {
      return NextResponse.json({ error: "Card ID already exists." }, { status: 409 });
    }

    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: error.errors[0]?.message || "Invalid payload." }, { status: 400 });
    }

    return NextResponse.json({ error: "Failed to create card." }, { status: 500 });
  }
}