import { NextResponse } from "next/server";
import { z } from "zod";
import { deleteCard, getCardById, updateCard } from "@/lib/card-service";

const updateSchema = z.object({
  title: z.string().trim().min(1).optional(),
  category: z.string().optional(),
  images: z.array(z.string().trim().min(1)).optional(),
  videoUrl: z.string().trim().nullable().optional(),
  musicUrl: z.string().trim().nullable().optional(),
  message: z.string().optional()
});

export async function GET(_: Request, { params }: { params: { cardId: string } }) {
  const card = await getCardById(params.cardId);

  if (!card) {
    return NextResponse.json({ error: "Card not found." }, { status: 404 });
  }

  return NextResponse.json(card);
}

export async function PUT(request: Request, { params }: { params: { cardId: string } }) {
  try {
    const body = await request.json();
    const parsed = updateSchema.parse(body);

    const card = await updateCard(params.cardId, {
      title: parsed.title,
      category: parsed.category,
      images: parsed.images,
      videoUrl: parsed.videoUrl ?? undefined,
      musicUrl: parsed.musicUrl ?? undefined,
      message: parsed.message
    });

    return NextResponse.json(card);
  } catch (error: any) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: error.errors[0]?.message || "Invalid payload." }, { status: 400 });
    }

    return NextResponse.json({ error: "Failed to update card." }, { status: 500 });
  }
}

export async function DELETE(_: Request, { params }: { params: { cardId: string } }) {
  try {
    await deleteCard(params.cardId);
    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: "Failed to delete card." }, { status: 500 });
  }
}