import Link from "next/link";
import { listCards } from "@/lib/card-service";

export default async function HomePage() {
  const cards = await listCards();

  return (
    <main
      style={{
        minHeight: "100vh",
        padding: "48px 20px",
        background: "linear-gradient(180deg,#1f0d1d,#140b11)",
      }}
    >
      <div style={{ maxWidth: 1100, margin: "0 auto" }}>
        <div style={{ textAlign: "center", marginBottom: 30 }}>
          <h1 style={{ margin: 0, fontSize: "clamp(2rem, 3vw, 3.3rem)" }}>
            Love Card Platform
          </h1>
          <p style={{ opacity: 0.8, marginTop: 10, fontSize: 18 }}>
            Share memories, love messages, and special moments in one beautiful card.
          </p>
        </div>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))",
            gap: 24
          }}
        >
          {cards.map((card) => (
            <Link key={card.id} href={`/card/${card.id}`} style={{ display: "block" }}>
              <div
                style={{
                  background: "rgba(255,255,255,0.05)",
                  border: "1px solid rgba(255,255,255,0.1)",
                  borderRadius: 18,
                  overflow: "hidden",
                  boxShadow: "0 18px 36px rgba(0,0,0,0.22)",
                  transition: "transform 0.2s ease",
                }}
              >
                <img
                  src={
                    card.images[0] ||
                    "https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=900&q=80"
                  }
                  alt={card.title}
                  style={{
                    width: "100%",
                    height: 220,
                    objectFit: "cover",
                    display: "block"
                  }}
                />

                <div style={{ padding: 20 }}>
                  <div style={{ fontWeight: 700, fontSize: 18 }}>{card.title}</div>
                  <div style={{ marginTop: 8, opacity: 0.8, fontSize: 14 }}>
                    Category: {card.category}
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>

        <div style={{ textAlign: "center", marginTop: 30 }}>
          <Link
            href="/admin"
            style={{
              display: "inline-block",
              padding: "12px 22px",
              borderRadius: 999,
              background: "#ff8ccf",
              color: "#1f0917",
              fontWeight: 700
            }}
          >
            + Create Card
          </Link>
        </div>
      </div>
    </main>
  );
}