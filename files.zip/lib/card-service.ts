import { prisma } from "@/lib/prisma";

export type CardRecord = {
  id: string;
  title: string;
  category: string;
  images: string[];
  videoUrl: string | null;
  musicUrl: string | null;
  message: string;
  createdAt: Date;
  updatedAt: Date;
};

export type CardInput = {
  id?: string;
  title: string;
  category?: string;
  images?: string[];
  videoUrl?: string | null;
  musicUrl?: string | null;
  message?: string;
};

export async function listCards(): Promise<CardRecord[]> {
  return prisma.card.findMany({
    orderBy: { createdAt: "desc" },
  });
}

export async function getCardById(cardId: string): Promise<CardRecord | null> {
  return prisma.card.findUnique({
    where: { id: cardId },
  });
}

export async function createCard(data: CardInput): Promise<CardRecord> {
  return prisma.card.create({
    data: {
      id: data.id ?? crypto.randomUUID(),
      title: data.title,
      category: data.category ?? "love",
      images: data.images ?? [],
      videoUrl: data.videoUrl ?? null,
      musicUrl: data.musicUrl ?? null,
      message: data.message ?? "",
    },
  });
}

export async function updateCard(
  cardId: string,
  data: Partial<CardInput>
): Promise<CardRecord> {
  return prisma.card.update({
    where: { id: cardId },
    data: {
      title: data.title,
      category: data.category,
      images: data.images,
      videoUrl: data.videoUrl,
      musicUrl: data.musicUrl,
      message: data.message,
    },
  });
}

export async function deleteCard(cardId: string): Promise<CardRecord> {
  return prisma.card.delete({
    where: { id: cardId },
  });
}