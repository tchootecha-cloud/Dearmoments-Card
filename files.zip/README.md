# Love Card Platform

Production-ready Next.js + Prisma + PostgreSQL digital card platform.

## Features
- Public card page
- Admin dashboard
- CRUD API
- Image gallery / video / music / message
- Prisma ORM + PostgreSQL
- Docker support
- Render deployment example

## Prerequisites
- Node.js 20+
- npm
- PostgreSQL or Docker

## Local development

### 1) Start PostgreSQL
```bash
docker compose up -d postgres