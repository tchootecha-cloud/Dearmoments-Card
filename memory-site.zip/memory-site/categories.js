// หมวดความทรงจำ + โทนสี + ประโยคเริ่มต้น (เพิ่มหมวดใหม่ได้ที่นี่)
module.exports = [
  { id: 'love',        name: 'บอกรัก',        emoji: '💖', bg1: '#ffe3ec', bg2: '#ffb8cf', accent: '#ff4d88', accent2: '#ff9a8b', text: '#5a1d35' },
  { id: 'congrats',    name: 'แสดงความยินดี',  emoji: '🎉', bg1: '#fff4d6', bg2: '#ffd98a', accent: '#f5a623', accent2: '#ff7e5f', text: '#5c3d00' },
  { id: 'birthday',    name: 'วันเกิด',        emoji: '🎂', bg1: '#efe3ff', bg2: '#cdb4ff', accent: '#8e5cf7', accent2: '#ff8bd0', text: '#2f1a5c' },
  { id: 'thanks',      name: 'ขอบคุณ',        emoji: '🌿', bg1: '#e2f6ec', bg2: '#a9e3c6', accent: '#2fb67c', accent2: '#8fd8e0', text: '#124a35' },
  { id: 'sorry',       name: 'ขอโทษ',         emoji: '🕊️', bg1: '#e3f0ff', bg2: '#b3d4ff', accent: '#4a90e2', accent2: '#9fb8ff', text: '#17325c' },
  { id: 'missyou',     name: 'คิดถึง',         emoji: '🌙', bg1: '#e4e6ff', bg2: '#aeb4f5', accent: '#5c6bff', accent2: '#b48cff', text: '#1f2457' },
  { id: 'anniversary', name: 'ครบรอบ',        emoji: '💍', bg1: '#fbe0e4', bg2: '#e8a1ae', accent: '#c2395a', accent2: '#f08a5d', text: '#4d1423' },
  { id: 'cheer',       name: 'ให้กำลังใจ',     emoji: '☀️', bg1: '#fff0dc', bg2: '#ffc98f', accent: '#ff8a3d', accent2: '#ffd166', text: '#5a2e0a' },
  { id: 'remember',    name: 'ระลึกถึง',       emoji: '🕯️', bg1: '#ececf2', bg2: '#c4c4d4', accent: '#7a7a96', accent2: '#b9a7d6', text: '#2b2b3d' }
];
