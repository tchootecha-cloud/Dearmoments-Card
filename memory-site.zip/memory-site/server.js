const express = require('express');
const multer = require('multer');
const QRCode = require('qrcode');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const categories = require('./categories');

try { fs.readFileSync('.env', 'utf8').split('\n').forEach(l => { const m = l.match(/^\s*([A-Z_]+)\s*=\s*(.*)\s*$/); if (m && !process.env[m[1]]) process.env[m[1]] = m[2]; }); } catch {}

const PORT = process.env.PORT || 3000;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'change-me';
const BASE_URL = (process.env.BASE_URL || `http://localhost:${PORT}`).replace(/\/$/, '');
const SECRET = crypto.createHash('sha256').update('memory-secret:' + ADMIN_PASSWORD).digest('hex');

const DATA_DIR = path.join(__dirname, 'data');
const UPLOAD_DIR = path.join(DATA_DIR, 'uploads');
const DB_FILE = path.join(DATA_DIR, 'db.json');
fs.mkdirSync(UPLOAD_DIR, { recursive: true });
const loadDb = () => { try { return JSON.parse(fs.readFileSync(DB_FILE, 'utf8')); } catch { return {}; } };
const saveDb = db => fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));

// ID สุ่มยาว 16 ตัวอักษร (~96 bit) เดาไม่ได้ ไม่ซ้ำกัน
const newId = () => crypto.randomBytes(12).toString('base64url');

const app = express();
app.use(express.json());

// ---------- Auth (เฉพาะหลังบ้าน) ----------
const token = () => crypto.createHmac('sha256', SECRET).update('admin').digest('hex');
const getCookie = (req, k) => (req.headers.cookie || '').split(';').map(s => s.trim()).find(s => s.startsWith(k + '='))?.slice(k.length + 1);
const isAdmin = req => getCookie(req, 'auth') === token();
const requireAdmin = (req, res, next) => isAdmin(req) ? next() : res.status(401).json({ error: 'unauthorized' });

app.post('/api/login', (req, res) => {
  if (req.body.password !== ADMIN_PASSWORD) return res.status(401).json({ error: 'รหัสผ่านไม่ถูกต้อง' });
  res.setHeader('Set-Cookie', `auth=${token()}; HttpOnly; SameSite=Lax; Path=/; Max-Age=2592000`);
  res.json({ ok: true });
});
app.post('/api/logout', (req, res) => { res.setHeader('Set-Cookie', 'auth=; Path=/; Max-Age=0'); res.json({ ok: true }); });
app.get('/api/me', (req, res) => res.json({ admin: isAdmin(req) }));

// ---------- Upload ----------
const upload = multer({
  storage: multer.diskStorage({
    destination: UPLOAD_DIR,
    filename: (req, file, cb) => cb(null, newId() + path.extname(file.originalname).toLowerCase().replace(/[^.a-z0-9]/g, ''))
  }),
  limits: { fileSize: 100 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const ok = (file.fieldname === 'photo' && file.mimetype.startsWith('image/')) ||
               (file.fieldname === 'video' && file.mimetype.startsWith('video/'));
    cb(ok ? null : new Error('ไฟล์ไม่ถูกต้อง'), ok);
  }
});
const fields = upload.fields([{ name: 'photo', maxCount: 1 }, { name: 'video', maxCount: 1 }]);

const linkOf = id => `${BASE_URL}/m/${id}`;

// ---------- Admin API ----------
app.get('/api/categories', (req, res) => res.json(categories));

app.get('/api/memories', requireAdmin, (req, res) => {
  const db = loadDb();
  res.json(Object.values(db).sort((a, b) => b.createdAt - a.createdAt).map(m => ({ ...m, link: linkOf(m.id) })));
});

app.post('/api/memories', requireAdmin, (req, res) => {
  fields(req, res, async err => {
    if (err) return res.status(400).json({ error: err.message });
    const { category, message } = req.body;
    if (!categories.find(c => c.id === category)) return res.status(400).json({ error: 'กรุณาเลือกหมวด' });
    const db = loadDb();
    let id; do { id = newId(); } while (db[id]);
    const m = {
      id, category,
      message: (message || '').slice(0, 1000),
      photo: req.files?.photo?.[0]?.filename || null,
      video: req.files?.video?.[0]?.filename || null,
      createdAt: Date.now()
    };
    db[id] = m; saveDb(db);
    const link = linkOf(id);
    res.json({ ...m, link, qr: await QRCode.toDataURL(link, { width: 600, margin: 2 }) });
  });
});

app.get('/api/memories/:id/qr', requireAdmin, async (req, res) => {
  res.json({ qr: await QRCode.toDataURL(linkOf(req.params.id), { width: 600, margin: 2 }) });
});

app.delete('/api/memories/:id', requireAdmin, (req, res) => {
  const db = loadDb(); const m = db[req.params.id];
  if (!m) return res.status(404).json({ error: 'not found' });
  [m.photo, m.video].filter(Boolean).forEach(f => fs.unlink(path.join(UPLOAD_DIR, f), () => {}));
  delete db[req.params.id]; saveDb(db); res.json({ ok: true });
});

// ---------- Public (ไม่ต้องล็อกอิน) ----------
app.get('/api/public/:id', (req, res) => {
  const m = loadDb()[req.params.id];
  if (!m) return res.status(404).json({ error: 'not found' });
  res.set('Cache-Control', 'no-store');
  res.json({
    category: categories.find(c => c.id === m.category),
    message: m.message,
    photo: m.photo ? `/files/${m.photo}` : null,
    video: m.video ? `/files/${m.video}` : null
  });
});
app.use('/files', express.static(UPLOAD_DIR, { maxAge: '7d', index: false, dotfiles: 'deny' }));

app.get('/m/:id', (req, res) => { res.set('X-Robots-Tag', 'noindex'); res.sendFile(path.join(__dirname, 'public/view.html')); });
app.get('/admin', (req, res) => res.sendFile(path.join(__dirname, 'public/admin.html')));
app.get('/', (req, res) => res.redirect('/admin'));
app.get('/robots.txt', (req, res) => res.type('text').send('User-agent: *\nDisallow: /'));

app.listen(PORT, () => console.log(`Memory site: ${BASE_URL}/admin`));
