# Memory Site 💌

## รันบนเครื่อง
```
npm install
cp .env.example .env     # แก้ ADMIN_PASSWORD และ BASE_URL
npm start
```
- หลังบ้าน: http://localhost:3000/admin  (ล็อกอินด้วย ADMIN_PASSWORD)
- หน้าบ้าน: /m/<id>  ใครมีลิงก์/QR ก็เปิดได้ ไม่ต้องล็อกอิน

## ขึ้นออนไลน์
ใช้โฮสต์ที่รัน Node.js และมีดิสก์ถาวรได้ เช่น Render / Railway / Fly.io / VPS
ตั้ง Environment: ADMIN_PASSWORD, BASE_URL (โดเมนจริง, ต้องเป็น https) และเก็บโฟลเดอร์ `data/` ไว้บน persistent disk

## หมายเหตุ
- ID ของแต่ละความทรงจำสุ่ม 96 บิต ไม่ซ้ำและเดาไม่ได้ จึงไม่สแกนติดของคนอื่น
- เพิ่ม/แก้หมวดและสีที่ categories.js
